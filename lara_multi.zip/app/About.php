<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class About extends Model
{
    protected $fillable = [
        'first_t','first','first_s','second_t','third_t','fourth_t','second','third','fourth'
        ];
}
