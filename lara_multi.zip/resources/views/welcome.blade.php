 <!-- Footer Start -->
 <footer class="pl-40 pr-40">
            <!-- Footer Top Start -->
            <div class="footer-top ptb-40 white-bg">
                <div class="container">
                    <div class="row">
                        <!-- Single Footer Start -->
                        <div class="col-lg-3 col-md-3 col-sm-6">
                            <div class="single-footer">
                                <div class="footer-logo mb-20 pl-20">
                                    <a href="#"></a>
                                </div>
                                <div class="footer-content pl-20 pr-5">
                                    <ul class="footer-list first-content">
                                        <li><i class="zmdi zmdi-phone-in-talk"></i> +234 7035 614 322
</li>
                                        <li><i class="zmdi zmdi-email"></i><a href="#">mailto : support@motoka.ng</a></li>
                                        <li>
                                            <i class="zmdi zmdi-pin-drop"></i> Address : 23 Road G Close, Festac Town Lagos
                                        </li>
                                        <li></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <!-- Single Footer Start -->
                        <!-- Single Footer Start -->
                        <div class="col-lg-4 col-md-4 ml-80 col-sm-6">
                            <div class="single-footer">
                                <h3 class="footer-title">important links</h3>
                                <div class="footer-content">
                                    <ul class="footer-list">
                                        <li><a href="#">terms and conditions</a></li>
                                        <li><a href="/about">about us</a></li>
                                        <li><a href="/shop">shop</a></li>


                                    </ul>
                                </div>
                            </div>
                        </div>
                        <!-- Single Footer Start -->
                        <!-- Single Footer Start -->
                        <div class="col-lg-4 col-md-4 col-sm-6">
                            <div class="single-footer">
                                <h3 class="footer-title" style="margin-left:28px;">Our Vision</h3>
                                <div class="footer-content">
                                    <ul class="footer-list first-content">
                                    <li>Getting to over fifty countries and offering</li>
                                    <li> best and quality services that is highly</li>
                                     <li>appreciated and fully well served</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <!-- Single Footer Start -->
                        <!-- Single Footer Start -->

                        <!-- Single Footer Start -->
                    </div>
                    <!-- Row End -->
                </div>
                <!-- Container End -->
            </div>
            <!-- Footer Top End -->
            <!-- Footer Middle Start -->
            <div class="footer-middle ptb-30">
                <div class="container">
                    <div class="row">
                        <!-- Single Payment Service Start -->
                        <div class="col-sm-4">
                            <div class="single-service">
                                <div class="service-des">
                                    <h3>customer-satisfaction</h3>
                                    <p>our top priority is our customer's satisfaction!!</p>
                                </div>
                            </div>
                        </div>
                        <!-- Single Payment Service End -->
                        <!-- Single Payment Service Start -->
                        <div class="col-sm-4">
                            <div class="single-service serve-two">
                                <div class="service-des">
                                    <h3>Nationwide Delivery</h3>
                                    <p> We ship to over 30 states and regions.</p>
                                </div>
                            </div>
                        </div>
                        <!-- Single Payment Service End -->
                        <!-- Single Payment Service Start -->
                        <div class="col-sm-4">
                            <div class="single-service serve-three">
                                <div class="service-des">
                                    <h3>24/7 Help Center</h3>
                                    <p>Round-the-clock assistance for a smooth shopping experience.</p>
                                </div>
                            </div>
                        </div>
                        <!-- Single Payment Service End -->
                    </div>
                    <!-- Row End -->
                </div>
                <!-- Container End -->
            </div>
            <!-- Footer Middle End -->
            <!-- Footer Bottom Start -->
            <div class="footer-bottom ptb-30 white-bg">
                <div class="container">
                    <p class="f-left pl-20 pr-5">Copyright © <a href="#">Motoka NG</a> All Rights Reserved.</p>
                </div>
                <!-- Container End -->
            </div>
            <!-- Footer Bottom End -->
        </footer>
        <!-- Footer End -->
    </div>
    <!-- Wrapper End -->
    <!-- jquery 3.12.4 -->
    <script src="{{ asset('js/vendor/jquery-1.12.4.min.js') }}"></script>
    <!-- mobile menu js  -->
    <script src="{{ asset('js/jquery.meanmenu.min.js')}}"></script>
    <!-- scroll-up js -->
    <script src="{{ asset('js/jquery.scrollUp.js')}}"></script>
    <!-- owl-carousel js -->
    <script src="{{ asset('js/owl.carousel.min.js')}}"></script>
    <!-- countdown js -->
    <script src="{{ asset('js/jquery.countdown.min.js')}}"></script>
    <!-- wow js -->
    <script src="{{ asset('js/wow.min.js')}}"></script>
    <!-- price slider js -->
    <script src="{{ asset('js/jquery-ui.min.js')}}"></script>
    <!-- fancybox js -->
    <script src="{{ asset('js/jquery.fancybox.min.js')}}"></script>
    <!-- nivo slider js -->
    <script src="{{ asset('js/jquery.nivo.slider.js')}}"></script>
    <!-- bootstrap -->
    <script src="{{ asset('js/bootstrap.min.js')}}"></script>
    <!-- plugins -->
    <script src="{{ asset('js/plugins.js')}}"></script>
    <!-- main js -->
    <script src="{{ asset('js/main.js')}}"></script>
