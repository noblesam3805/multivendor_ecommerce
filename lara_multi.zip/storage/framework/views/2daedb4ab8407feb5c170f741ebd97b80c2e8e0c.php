<?php echo $__env->make("layout", \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<br><br>
<style>
body{
background-color:white !important;

}
</style>
            <div class="container pb-100 ">
            <div class="row pb-20 ">


                <div class="col-sm-6 col-md-9 col-lg-9">
                  <div class="thumbnail">
                    <div id="myCarousel" style="" class="carousel slide" data-ride="carousel">
    <!-- Indicators -->
    <ol class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
      <li data-target="#myCarousel" data-slide-to="2"></li>
      <li data-target="#myCarousel" data-slide-to="3"></li>
      <li data-target="#myCarousel" data-slide-to="4"></li>
      <li data-target="#myCarousel" data-slide-to="5"></li>
      <li data-target="#myCarousel" data-slide-to="6"></li>
    </ol>

    <!-- Wrapper for slides -->
    <div class="carousel-inner">
      <div class="item active">
        <img src="/storage/<?php echo e($posts->p_image); ?>" alt="Los Angeles" style="height:400px; width:100%;">
      </div>

      <div class="item">
        <img src="/storage/<?php echo e($posts->s_img); ?>" alt="Chicago" style="height:400px; width:400%;">
      </div>
    
      <div class="item">
        <img src="/storage/<?php echo e($posts->t_img); ?>" alt="New york" style="height:400px; width:100%;">
      </div>
      
       <div class="item">
        <img src="/storage/<?php echo e($posts->f_img); ?>" alt="New york" style="height:400px; width:100%;">
      </div>
      
        <div class="item">
        <img src="/storage/<?php echo e($posts->ft_img); ?>" alt="Los Angeles" style="height:400px; width:100%;">
      </div>

      <div class="item">
        <img src="/storage/<?php echo e($posts->sx_img); ?>" alt="Chicago" style="height:400px; width:400%;">
      </div>
    
      <div class="item">
        <img src="/storage/<?php echo e($posts->st_img); ?>" alt="New york" style="height:400px; width:100%;">
      </div>
    </div>

    <!-- Left and right controls -->
    <a class="left carousel-control" href="#myCarousel" data-slide="prev">
      <span class="glyphicon glyphicon-chevron-left"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" href="#myCarousel" data-slide="next">
      <span class="glyphicon glyphicon-chevron-right"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>
                    <div class="caption">
                      <h3><?php echo e($posts->p_name); ?></h3>
                      <p><?php echo e($posts->p_price); ?></p>
</div>
                    </div>
                  </div>
                  <table class="table table-hover" style="width:50%;" >
    <thead>
      <tr>
        <th>Seller</th>
        <th>Product Category</th>
        <th>Contact Admin</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>Admin</td>
        <td><?php echo e($posts->p_cat); ?></td>
        <td>08099456789</td>
      </tr>

    </tbody>
  </table>
  
  <table class="table table-hover" style="width:50%;">
    <thead>
      <tr>

        <th> Mileage</th>

      </tr>
    </thead>
    <tbody>
      <tr>
        <td><?php echo e($posts->p_mile); ?></td>
      </tr>

    </tbody>
  </table>

  <table class="table table-hover" style="width:50%;">
    <thead>
      <tr>

        <th>Product Description</th>

      </tr>
    </thead>
    <tbody>
      <tr>
        <td><?php echo e($posts->descr); ?></td>
      </tr>

    </tbody>
  </table>

  <br><br>
  <form action="/store/<?php echo e($posts->id); ?>" method="post">
                     <?php echo csrf_field(); ?>

 <span class="bg-warning p-20" style="margin:0 50px 50px 0;">N.B *You must be logged in to comment/reply*</span><br><br>
                <div class="form-group col-md-6" style="width:60%;">
                   
                  <label for="descr">Drop a Comment</label>
                 <textarea name="body" required class="form-control" style="height:200px;"></textarea><br>
                 <button type="submit" style="border:2px;
                      border-radius:10px;" class="btn btn-primary">Comment</button>

                </div>

                </form>
                </div>

            <?php $__currentLoopData = $posts->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $poss): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-sm-6 col-md-6 col-lg-12 mb-10" style="border:2px solid #0162BD;
                      width:60%; border-radius:10px;">
                      <p class="pt-10"><?php echo e($poss->user->name); ?> : <?php echo e($poss->body); ?></p><br>
                      <?php if($poss->user->name == Auth::user()->name): ?>
                      <a href="<?php echo e($poss->body); ?>" class="btn btn-primary mb-10" style="border:2px;
                      border-radius:10px;" data-toggle="modal" data-target="#<?php echo e($poss->id); ?>">Edit</a><?php endif; ?><br>
                       <?php $__currentLoopData = $poss->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <div class="col-sm-6 col-md-6 col-lg-12 mb-10" style="border:2px solid #0162BD;
                      width:100%; border-radius:10px;">
                      <p class="pt-10"><?php echo e($reply->user->name); ?> : <?php echo e($reply->body); ?></p><br>
                      <?php if($reply->user->name == Auth::user()->name): ?>
                      <a href="#" class="btn btn-primary mb-10" style="border:2px;
                      border-radius:10px;" data-toggle="modal" role="dialog"
                       data-target="#<?php echo e($reply->id); ?>">Edit</a>
                       <?php endif; ?>
                    </div>

                     <!-- 2nd Modal -->
                     <div id="<?php echo e($reply->id); ?>" class="modal fade" role="dialog">
                        <div class="modal-dialog">

                            <!-- Modal content-->
                            <div class="modal-content" style="padding:30px">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                    <h4 class="modal-title">Edit your previous reply</h4>
                                </div>
                            <form method="post" action="<?php echo e(route('reply.update',$reply->id)); ?>">
                                <?php echo csrf_field(); ?>

                                     <input type="text" name="body" required class="form-control"
                                     style="height:100px;" value="<?php echo e($reply->body); ?>"><br>
                                     <button type="submit" class="btn btn-primary mb-10" style="border:2px;
                                     border-radius:5px;">Update</button>

                            </form>
                                    </div>
                                </div>
                           </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       <form method="post" action="<?php echo e(route('commen.reply',$poss->id)); ?>">
                                <?php echo csrf_field(); ?>

                                     <input type="text" name="body" required class="form-control"
                                     style="height:80px;" value=""><br>
                                     <button type="submit" class="btn btn-primary mb-10" style="border:2px;
                                     border-radius:5px;">Reply</button>

                        </form>
                    </div>
                    <br>
                    <!-- Modal -->
                    <div id="<?php echo e($poss->id); ?>" class="modal fade" role="dialog">
                        <div class="modal-dialog">

                            <!-- Modal content-->
                            <div class="modal-content" style="padding:30px">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                    <h4 class="modal-title">Edit your previous comment</h4>
                                </div>
                            <form method="post" action="<?php echo e(route('comment.update',$poss->id)); ?>">
                                <?php echo csrf_field(); ?>

                                     <input type="text" name="body" required class="form-control"
                                     style="height:100px;" value="<?php echo e($poss->body); ?>"><br>
                                     <button type="submit" class="btn btn-primary mb-10" style="border:2px;
                                     border-radius:5px;">Update</button>

                            </form>
                                    </div>
                                </div>
                           </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>



<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
