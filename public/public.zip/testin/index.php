<?php 

echo "hiiiiiiiiiiii";

?>